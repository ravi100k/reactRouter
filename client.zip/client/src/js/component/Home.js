var React=require("React");

 var Home=React.createClass({

   render: function() {
     return (
       <div>
       Home is there..............
       </div>
     )
   }
 });
 module.exports = Home;
