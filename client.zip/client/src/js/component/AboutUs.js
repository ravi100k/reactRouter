var React=require("React");

 var AboutUs=React.createClass({

   render: function() {
     return (
       <div>
       
       AboutUs is there..............
       </div>
     )
   }
 });
 module.exports = AboutUs;
